#include "Packet.hpp"
#include <cstdio>
#include <cstring>
using namespace ZeroTier;
int main(){Packet p(Address(1),Address(2),Packet::VERB_FRAME);for(int i=0;i<500;i++)p.append((uint8_t)'A');Packet original(p);bool first=p.compress();bool firstFlag=p.compressed();unsigned int firstLen=p.size();bool second=p.compress();bool secondFlag=p.compressed();bool dec=p.uncompress();bool same=p.size()==original.size()&&!memcmp(p.data(),original.data(),p.size());std::printf("first=%d flag=%d len=%u second=%d flag=%d decompress=%d roundtrip_equal=%d\n",first,firstFlag,firstLen,second,secondFlag,dec,same);return same?0:2;}
