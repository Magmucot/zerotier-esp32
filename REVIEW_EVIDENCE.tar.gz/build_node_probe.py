from pathlib import Path
import subprocess
R=Path(__file__).parent;S=Path('/workspace/zerotier-esp32/ZeroTierOne/node');P=S.parent.parent/'components/zerotier_node/port'
limits=['ZT_NETWORKCONFIG_DICT_CAPACITY_OVERRIDE=4096','ZT_MAX_NETWORK_ROUTES=8','ZT_MAX_ZT_ASSIGNED_ADDRESSES=4','ZT_MAX_NETWORK_SPECIALISTS=8','ZT_MAX_NETWORK_RULES=32','ZT_MAX_NETWORK_CAPABILITIES=1','ZT_MAX_NETWORK_TAGS=1','ZT_MAX_CERTIFICATES_OF_OWNERSHIP=1','ZT_MAX_CAPABILITY_RULES=1','ZT_MAX_DNS_SERVERS=1','ZT_MAX_MULTICAST_SUBSCRIPTIONS=16','ZT_RX_QUEUE_SIZE=4','ZT_TX_QUEUE_SIZE=4','ZT_MAX_PACKET_FRAGMENTS=2','ZT_DEFAULT_PHYSMTU=1280','ZT_LAST_IDENTITY_VERIFICATION_SIZE=256','ZT_ESP32_ALLOW_PROVISIONED_IDENTITY=1']
src=[str(x) for x in S.glob('*.cpp') if x.name not in ['AES_armcrypto.cpp','Bond.cpp','Metrics.cpp','Trace.cpp']]
cmd=['g++','-std=c++17','-g','-O1','-pthread','-maes','-mpclmul','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-DZT_NO_TYPE_PUNNING','-DZT_NO_UNALIGNED_ACCESS','-I'+str(S),'-I'+str(S.parent/'osdep'),'-I'+str(P/'stubs'),'-include','thread',*['-D'+x for x in limits],str(R/'probe_node.cpp'),*src,*[str(P/x) for x in ['zt_bond_esp.cpp','zt_metrics_esp.cpp','zt_trace_esp.cpp','zt_osutils_esp.cpp']],'-o',str(R/'probe_node')]
with (R/'evidence/node-probe-build.log').open('w') as f:
 f.write('$ '+' '.join(cmd)+'\n');f.flush();p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT);f.write(f'\nexit={p.returncode}\n')
print('build exit',p.returncode)
if not p.returncode:
 with (R/'evidence/node-malformed-hello.log').open('w') as f:
  p=subprocess.run([str(R/'probe_node')],stdout=f,stderr=subprocess.STDOUT);f.write(f'\nexit={p.returncode}\n')
 print('probe exit',p.returncode)
