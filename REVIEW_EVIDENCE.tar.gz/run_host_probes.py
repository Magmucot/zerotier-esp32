from pathlib import Path
import subprocess,os
os.environ['ASAN_OPTIONS']='detect_leaks=0'
R=Path(__file__).parent
S=Path('/workspace/zerotier-esp32/ZeroTierOne/node')
flags=['-std=c++17','-g','-O1','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-pthread','-DZT_NO_TYPE_PUNNING','-DZT_NO_UNALIGNED_ACCESS','-I'+str(S),'-I/workspace/zerotier-esp32/components/zerotier_node/port/stubs','-include','thread']
limits=['ZT_NETWORKCONFIG_DICT_CAPACITY_OVERRIDE=4096','ZT_MAX_NETWORK_ROUTES=8','ZT_MAX_ZT_ASSIGNED_ADDRESSES=4','ZT_MAX_NETWORK_SPECIALISTS=8','ZT_MAX_NETWORK_RULES=32','ZT_MAX_NETWORK_CAPABILITIES=1','ZT_MAX_NETWORK_TAGS=1','ZT_MAX_CERTIFICATES_OF_OWNERSHIP=1','ZT_MAX_CAPABILITY_RULES=1','ZT_MAX_DNS_SERVERS=1']
def run(name,args):
 p=subprocess.run(args,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (R/'evidence'/name).write_bytes(('$ '+' '.join(map(str,args))+'\n').encode()+p.stdout+f'\nexit={p.returncode}\n'.encode())
 print(name,'exit',p.returncode,p.stdout.decode(errors='replace')[-1000:]);return p
p=run('parser-build.log',['g++',*flags,*['-D'+x for x in limits],'-fsanitize=address,undefined','-fno-omit-frame-pointer',str(R/'probe_parser.cpp'),str(S/'NetworkConfig.cpp'),str(S/'InetAddress.cpp'),str(S/'Utils.cpp'),'-o',str(R/'probe_parser')])
if p.returncode==0:
 for case in ['clean','tags','caps','rules','routes','identity-abort']:run('parser-'+case+'.log',[str(R/'probe_parser'),case])
for mem in [2097152,65536]:
 p=run(f'identity-build-{mem}.log',['g++',*flags,f'-DZT_IDENTITY_GEN_MEMORY_OVERRIDE={mem}',str(R/'probe_identity.cpp'),*[str(S/x) for x in ['Identity.cpp','ECC.cpp','SHA512.cpp','Salsa20.cpp','Utils.cpp']],'-o',str(R/f'identity-{mem}')])
 if p.returncode==0:
  p=run(f'identity-generate-{mem}.log',[str(R/f'identity-{mem}')]);(R/f'identity-{mem}.temporary').write_bytes(p.stdout)
for src in [2097152,65536]:
 for validator in [2097152,65536]:
  if (R/f'identity-{validator}').exists():run(f'identity-{src}-validate-{validator}.log',[str(R/f'identity-{validator}'),str(R/f'identity-{src}.temporary')])
