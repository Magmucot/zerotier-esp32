#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cerrno>
#include <cstdio>
#include <cstdint>
struct ZT_Node;
struct ESP32LitePort {int _udpSocket;static int wirePacketSendCallback(ZT_Node*,void*,void*,int64_t,const sockaddr_storage*,const void*,unsigned int,unsigned int);};
int ESP32LitePort::wirePacketSendCallback(ZT_Node*, void* userPtr, void*, int64_t localSocket, const struct sockaddr_storage* remoteAddress, const void* packetData, unsigned int packetLength, unsigned int ttl)
{
	ESP32LitePort* self = (ESP32LitePort*)userPtr;
	if ((! self) || (! remoteAddress) || (! packetData) || (self->_udpSocket < 0)) {
		return -1;
	}
	(void)localSocket;
	if (ttl) {
		if (remoteAddress->ss_family == AF_INET) {
			setsockopt(self->_udpSocket, IPPROTO_IP, IP_TTL, &ttl, sizeof(ttl));
		}
#ifdef IPV6_UNICAST_HOPS
		else if (remoteAddress->ss_family == AF_INET6) {
			setsockopt(self->_udpSocket, IPPROTO_IPV6, IPV6_UNICAST_HOPS, &ttl, sizeof(ttl));
		}
#endif
	}
	const socklen_t slen = (remoteAddress->ss_family == AF_INET6) ? sizeof(struct sockaddr_in6) : sizeof(struct sockaddr_in);
	const int rc = (int)sendto(self->_udpSocket, packetData, packetLength, 0, (const struct sockaddr*)remoteAddress, slen);
	if (rc == (int)packetLength) {
		return 0;
	}
	if ((rc < 0) && ((errno == EAGAIN) || (errno == EWOULDBLOCK))) {
		return -1;
	}
	return -1;
}

int main(){ESP32LitePort port;port._udpSocket=socket(AF_INET,SOCK_DGRAM,0);int ttl; socklen_t n=sizeof(ttl);getsockopt(port._udpSocket,IPPROTO_IP,IP_TTL,&ttl,&n);printf("initial_ttl=%d\n",ttl);sockaddr_in dst={};dst.sin_family=AF_INET;dst.sin_addr.s_addr=htonl(INADDR_LOOPBACK);dst.sin_port=htons(9);char data='a';port.wirePacketSendCallback(nullptr,&port,nullptr,0,(const sockaddr_storage*)&dst,&data,1,2);port.wirePacketSendCallback(nullptr,&port,nullptr,0,(const sockaddr_storage*)&dst,&data,1,0);getsockopt(port._udpSocket,IPPROTO_IP,IP_TTL,&ttl,&n);printf("ttl_after_probe_and_normal_send=%d\n",ttl);close(port._udpSocket);}
