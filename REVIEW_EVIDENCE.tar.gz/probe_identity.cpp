#include "Identity.hpp"
#include <cstdio>
#include <string>
#include <fstream>
int main(int argc,char**argv) {
  ZeroTier::Identity id;
  if (argc==1) { id.generate(); char s[ZT_IDENTITY_STRING_BUFFER_LENGTH]; std::puts(id.toString(false,s)); return !id.locallyValidate(); }
  std::ifstream f(argv[1]); std::string s; std::getline(f,s);
  bool parsed=id.fromString(s.c_str()); bool valid=parsed&&id.locallyValidate();
  std::printf("parsed=%d locallyValidate=%d\n",parsed,valid); return valid?0:2;
}
