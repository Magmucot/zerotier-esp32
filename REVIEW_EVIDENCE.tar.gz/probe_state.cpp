#include "ESP32NetworkState.hpp"
#include "ESP32EthernetTap.hpp"
#include <cstdio>
#include <cstring>
using namespace ZeroTier;
static unsigned created=0,subscribes=0;static uint64_t createdNwid=0;
namespace ZeroTier {
EthernetTap::EthernetTap(){} EthernetTap::~EthernetTap(){}
bool EthernetTap::addIps(std::vector<InetAddress> v){for(auto&i:v)if(!addIp(i))return false;return true;}
std::string EthernetTap::friendlyName()const{return "fixture";}
std::shared_ptr<EthernetTap> EthernetTap::newInstance(const char*,unsigned int,bool,const char*h,const MAC&m,unsigned int mtu,unsigned int metric,uint64_t nwid,const char*name,void(*fn)(void*,void*,uint64_t,const MAC&,const MAC&,unsigned int,unsigned int,const void*,unsigned int),void*a){++created;createdNwid=nwid;return std::shared_ptr<EthernetTap>(new ESP32EthernetTap(h,m,mtu,metric,nwid,name,fn,a));}
ManagedRoute::ManagedRoute(const InetAddress&t,const InetAddress&v,const InetAddress&s,const char*){_target=t;_via=v;_src=s;}
ManagedRoute::~ManagedRoute(){} bool ManagedRoute::sync(){return true;}void ManagedRoute::remove(){}
}
extern "C" ZT_ResultCode ZT_Node_multicastSubscribe(ZT_Node*,void*,uint64_t,uint64_t,unsigned long){++subscribes;return ZT_RESULT_ERROR_NETWORK_NOT_FOUND;}
extern "C" ZT_ResultCode ZT_Node_multicastUnsubscribe(ZT_Node*,uint64_t,uint64_t,unsigned long){return ZT_RESULT_OK;}
static ZT_VirtualNetworkConfig cfg(){ZT_VirtualNetworkConfig c={};c.nwid=1;c.mac=0x020000000001ULL;c.mtu=1280;c.status=ZT_NETWORK_STATUS_OK;return c;}
static void ip(ZT_VirtualNetworkConfig&c,int i,const char*s){InetAddress a(s);memcpy(&c.assignedAddresses[i],&a,sizeof(a));}
static void apply(ESP32NetworkState&s,ZT_VirtualNetworkConfig&c){s.applyConfigFromOwnerTask((ZT_Node*)1,nullptr,ZT_VIRTUAL_NETWORK_CONFIG_OPERATION_CONFIG_UPDATE,&c);}
int main(){
 {ESP32NetworkState s("/",nullptr,nullptr);auto c=cfg();c.assignedAddressCount=1;ip(c,0,"192.0.2.5/24");apply(s,c);unsigned old=subscribes;apply(s,c);printf("failed_subscribe attempts_first=%u attempts_after_retry=%u\n",old,subscribes);ip(c,0,"192.0.2.5/16");apply(s,c);printf("prefix_after_change=%u expected=16\n",s.tap()->ips()[0].netmaskBits());s.applyConfigFromOwnerTask((ZT_Node*)1,nullptr,ZT_VIRTUAL_NETWORK_CONFIG_OPERATION_DOWN,&c);apply(s,c);printf("subscribe_after_down_up=%u\n",subscribes);unsigned before=created;c.nwid=2;apply(s,c);printf("second_network state_nwid=%llu tap_created_nwid=%llu new_taps=%u\n",(unsigned long long)s.nwid(),(unsigned long long)createdNwid,created-before);}
 {ESP32NetworkState s("/",nullptr,nullptr);auto c=cfg();c.assignedAddressCount=4;for(int i=0;i<4;i++){char b[64];snprintf(b,sizeof(b),"192.0.2.%d/24",10+i);ip(c,i,b);}apply(s,c);for(int i=0;i<4;i++){char b[64];snprintf(b,sizeof(b),"198.51.100.%d/24",10+i);ip(c,i,b);}apply(s,c);printf("full_address_replacement count=%u expected=4\n",s.managedIpCount());}
}
