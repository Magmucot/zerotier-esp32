#include "ESP32LwIPGlue.hpp"
#include <cstdio>
void(*pending_cb)(void*)=nullptr;void*pending_arg=nullptr;
int main(){bool ready=ZeroTier::ESP32LwIPGlue::captureTcpipThread(1);std::printf("capture=%d; running delayed tcpip callback\n",ready);fflush(stdout);pending_cb(pending_arg);}
