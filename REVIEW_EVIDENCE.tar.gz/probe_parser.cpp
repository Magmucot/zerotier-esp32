#include "NetworkConfig.hpp"
#include "Identity.hpp"
#include <cstdio>
#include <cstring>
using namespace ZeroTier;
int main(int argc,char**argv) {
 const char* mode=argc>1?argv[1]:"clean";
 if(!std::strcmp(mode,"identity-abort")) { Buffer<128> b; for(int i=0;i<5;i++)b.append((uint8_t)1); b.append((uint8_t)1); Identity id; try {id.deserialize(b,0);} catch(...) {puts("caught");return 0;} return 3; }
 Dictionary<ZT_NETWORKCONFIG_DICT_CAPACITY> d;
 d.add("v",(uint64_t)6);d.add("nwid",(uint64_t)1);d.add("id",(uint64_t)2);
 if(!std::strcmp(mode,"tags")) { Buffer<1024>b; Tag t; t.serialize(b);t.serialize(b);d.add("TAG",(const char*)b.data(),b.size()); }
 if(!std::strcmp(mode,"caps")) { Buffer<1024>b; for(int j=0;j<2;j++){b.append((uint64_t)1);b.append((uint64_t)0);b.append((uint32_t)j);b.append((uint16_t)0);b.append((uint8_t)1);for(int i=0;i<5;i++)b.append((uint8_t)0);b.append((uint16_t)0);}d.add("CAP",(const char*)b.data(),b.size()); }
 if(!std::strcmp(mode,"rules")) { Buffer<1024>b; for(int i=0;i<33;i++){b.append((uint8_t)ZT_NETWORK_RULE_ACTION_ACCEPT);b.append((uint8_t)0);}d.add("R",(const char*)b.data(),b.size()); }
 if(!std::strcmp(mode,"routes")) { Buffer<1024>b; InetAddress target("192.0.2.0/24"),via; for(int i=0;i<9;i++){target.serialize(b);via.serialize(b);b.append((uint16_t)0);b.append((uint16_t)0);}d.add("RT",(const char*)b.data(),b.size()); }
 NetworkConfig c;bool ok=c.fromDictionary(d);
 std::printf("mode=%s ok=%d tags=%u caps=%u rules=%u routes=%u sizeof=%zu\n",mode,ok,c.tagCount,c.capabilityCount,c.ruleCount,c.routeCount,sizeof(c));
 return 0;
}
