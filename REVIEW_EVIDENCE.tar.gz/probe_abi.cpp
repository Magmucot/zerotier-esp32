#include "ZeroTierOne.h"
#include <cstdio>
#include <cstddef>
int main(){std::printf("sizeof(ZT_VirtualNetworkConfig)=%zu routeCount.offset=%zu routes.offset=%zu dns.offset=%zu\n",sizeof(ZT_VirtualNetworkConfig),offsetof(ZT_VirtualNetworkConfig,routeCount),offsetof(ZT_VirtualNetworkConfig,routes),offsetof(ZT_VirtualNetworkConfig,dns));}
