#include "Node.hpp"
#include "Identity.hpp"
#include "Packet.hpp"
#include "InetAddress.hpp"
#include <cstdio>
#include <cstring>
using namespace ZeroTier;
static char identityText[ZT_IDENTITY_STRING_BUFFER_LENGTH];
static int get(ZT_Node*,void*,void*,ZT_StateObjectType t,const uint64_t*,void*data,unsigned int n){if(t!=ZT_STATE_OBJECT_IDENTITY_SECRET)return -1;unsigned int l=std::strlen(identityText);if(l>n)return -1;std::memcpy(data,identityText,l);return l;}
static void put(ZT_Node*,void*,void*,ZT_StateObjectType,const uint64_t*,const void*,int){}
static int wire(ZT_Node*,void*,void*,int64_t,const sockaddr_storage*,const void*,unsigned int,unsigned int){return 0;}
static void frame(ZT_Node*,void*,void*,uint64_t,void**,uint64_t,uint64_t,unsigned int,unsigned int,const void*,unsigned int){}
static int config(ZT_Node*,void*,void*,uint64_t,void**,ZT_VirtualNetworkConfigOperation,const ZT_VirtualNetworkConfig*){return 0;}
static void event(ZT_Node*,void*,void*,ZT_Event,const void*){}
int main(int argc,char**){
 setvbuf(stdout,nullptr,_IONBF,0);
 Identity id; id.generate();id.toString(true,identityText);
 ZT_Node_Callbacks cb={};cb.stateGetFunction=get;cb.statePutFunction=put;cb.wirePacketSendFunction=wire;cb.virtualNetworkFrameFunction=frame;cb.virtualNetworkConfigFunction=config;cb.eventCallback=event;
 ZT_Node_Config nc={};ZT_Node* node=nullptr;auto rc=ZT_Node_new(&node,argc>1?nullptr:&nc,nullptr,nullptr,&cb,10000);std::printf("node_rc=%d\n",rc);if(rc)return 4;
 Packet p(Address(ZT_Node_address(node)),Address(0x123456789aULL),Packet::VERB_HELLO);
 p.append((uint8_t)13);p.append((uint8_t)1);p.append((uint8_t)16);p.append((uint16_t)0);p.append((uint64_t)0);
 Address(0x123456789aULL).appendTo(p);p.append((uint8_t)1);
 InetAddress from("192.0.2.1/9993");int64_t next=0;
 puts("before_untrusted_hello");fflush(stdout);
 rc=ZT_Node_processWirePacket(node,nullptr,10001,-1,(const sockaddr_storage*)&from,p.data(),p.size(),&next);
 std::printf("after_untrusted_hello rc=%d\n",rc);ZT_Node_delete(node);return 0;
}
