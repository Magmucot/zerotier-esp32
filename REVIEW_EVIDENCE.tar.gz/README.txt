Independent audit artifact bundle.

REVIEW_REPORT.md is the full technical report.
evidence/ contains build logs, test results, upstream diff metadata and local probe logs.
probe_*.cpp, build_node_probe.py and run_host_probes.py are diagnostic sources.
Generated identity files, executables, and complete build directories are intentionally not included.
The upstream source repository was not modified.
